package com.Jsp.SDBMS.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Jsp.SDBMS.Dao.Studentdao;
import com.Jsp.SDBMS.Entity.Student;

@Service
public class StudentService {
	
	@Autowired
	private Studentdao studentdao ;
	
	public void saveStudent(Student student) {
		
		if(student != null && student.getName() != null && student.getPhno() != 0 ) {
			studentdao.saveStudent(student);
		}
	}
	
	public Student findStudent(int id) {
		
		if(id > 0) {
			return studentdao.findStudent(id) ;
		}
		else return null ;
	}
	
	public void updateStudent(Student updatestudent) {
		
		Student student = findStudent(updatestudent.getId());
		
		if(student != null) {
			studentdao.updateStudent(updatestudent);
		}
	}
	
	public boolean deleteStudent(int id) {
		
		Student student = findStudent(id) ;
		
		if(student != null) studentdao.deleteStudent(student) ;
		
		return false;
	}
	
	public List<Student> getAllStudent() {
		
		return studentdao.findAllStudent() ;
	}
	
}

package com.Jsp.SDBMS.Configuration;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.annotations.Comment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = "com.Jsp.SDBMS")
public class ConfigurationRegistration {

	@Bean
	public EntityManager createEntityManager() {
		return Persistence.createEntityManagerFactory("Zoro").createEntityManager() ;
	}
	
//	@Bean
//	public InternalResourceViewResolver configureInternalResourceViewResolver() {
//		
//		return new InternalResourceViewResolver("/WEB-INF/views/", ".jsp") ;
//		
//	}
}


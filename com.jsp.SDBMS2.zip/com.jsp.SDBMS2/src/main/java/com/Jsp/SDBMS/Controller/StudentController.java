package com.Jsp.SDBMS.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Jsp.SDBMS.Entity.Student;
import com.Jsp.SDBMS.Service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService service ;
	
	@RequestMapping(value = "addstudent", method = RequestMethod.GET)
	public ModelAndView addSrudent(ModelAndView mav, Student student) {
		
		mav.addObject("student", student) ;
		
		mav.setViewName("addstudent.jsp");
		
		return mav ;
		
	}
	
	@RequestMapping(value = "/saveStudent", method = RequestMethod.POST)
	public ModelAndView saveStudent(@ModelAttribute Student student, ModelAndView mav) {
		
		service.saveStudent(student) ;
		
		mav.setViewName("welcome.jsp") ;
		
		return mav ;
	}
	
	@RequestMapping(value = "findstudent")
	public ModelAndView findStduent(ModelAndView mav) {
		
		mav.setViewName("findstudent.jsp");
		
		return mav ;
	}
	
	@RequestMapping(value = "foundstudent", method = RequestMethod.POST)
	public ModelAndView foundStudent(ModelAndView mav, HttpServletRequest request) {
	    int id = Integer.parseInt(request.getParameter("id"));
	    Student student = service.findStudent(id);
	    mav.addObject("student", student); 
	    System.out.println(student);
	    mav.setViewName("showstudent.jsp"); 
	    return mav;
	}
	
	@RequestMapping(value = "getallstudent")
	public ModelAndView findAllStudent(ModelAndView mav) {
		List<Student> student = service.getAllStudent() ;
		mav.addObject("list", student) ;
		mav.setViewName("getallstudent.jsp");
		return mav ;
	}
	
	@RequestMapping(value = "update", method = RequestMethod.GET)
	public ModelAndView updateStudent(@RequestParam ("id") int id, ModelAndView mav) {
		
	    Student student = service.findStudent(id);
	    
	    mav.addObject("student", student);
	    mav.setViewName("updatestudent.jsp");
	    return mav;
	}

	
	@RequestMapping(value = "saveupdate", method = RequestMethod.POST)
	public ModelAndView saveUpdateStudent(@ModelAttribute Student student, ModelAndView mav) {
		
		service.updateStudent(student);
		
		mav.setViewName("welcome.jsp");
		
		return mav ;
	}
	
	@RequestMapping(value = "delete",method = RequestMethod.GET)
	public ModelAndView deleteStudent(@RequestParam ("id") int id, ModelAndView mav) {
		
		service.deleteStudent(id) ;
		
		mav.setViewName("getallstudent.jsp");
		List<Student> student = service.getAllStudent() ;
		mav.addObject("list", student) ;
		mav.setViewName("getallstudent.jsp");
		
		return mav ;
	}
}

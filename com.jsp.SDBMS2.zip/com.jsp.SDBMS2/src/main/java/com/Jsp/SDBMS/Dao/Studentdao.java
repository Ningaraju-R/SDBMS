package com.Jsp.SDBMS.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.Jsp.SDBMS.Entity.Student;

@Repository
public class Studentdao {
	
	@Autowired
	private EntityManager entityManager ;
	
	
	public void saveStudent(Student student) {
		
		EntityTransaction transaction = entityManager.getTransaction() ;
		
		transaction.begin();
		entityManager.persist(student);
		transaction.commit();
		
	}
	
	public Student findStudent(int id) {
		
		return entityManager.find(Student.class, id) ;
		
	}
	
	public void updateStudent(Student student) {
		
		EntityTransaction transaction = entityManager.getTransaction() ;
		
		transaction.begin();
		entityManager.merge(student) ;
		transaction.commit();
	}
	
	public List<Student> findAllStudent() {
	    return entityManager.createQuery("SELECT s FROM Student s", Student.class)
	                         .getResultList();
	}
	
	public boolean deleteStudent(Student student) {
		
		EntityTransaction transaction = entityManager.getTransaction() ;
		
		transaction.begin();
		entityManager.remove(student);
		transaction.commit();
		
		return true ;
	}


}

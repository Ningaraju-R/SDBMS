package com.Jsp.SDBMS.Configuration;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class WebIntializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	
	protected Class<?>[] getRootConfigClasses() {
		
		return null;
	}

	
	protected Class<?>[] getServletConfigClasses() {
		
		return new Class[] {ConfigurationRegistration.class};
	}

	
	protected String[] getServletMappings() {
		
		return new String [] {"/"};
	}

}
